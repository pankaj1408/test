import React from 'react';

const ApiKeyInstructions: React.FC = () => {
  return (
    <div className="w-full max-w-2xl mx-auto bg-slate-800/50 backdrop-blur-sm rounded-xl shadow-2xl shadow-slate-950/50 border border-yellow-500/50 p-6 md:p-8 text-slate-300 animate-fade-in">
      <h2 className="text-2xl font-bold text-yellow-400 mb-4">Deployment Setup Instructions</h2>
      <p className="mb-4">
        To run this application, you need a Google Gemini API key. Follow these steps in your server's terminal (e.g., after connecting to your EC2 instance via SSH).
      </p>

      <div className="space-y-6">
        <div>
          <h4 className="font-bold text-slate-100">Step 1: Set Your API Key</h4>
          <p className="text-sm mb-2">Run the following command, replacing <code className="bg-slate-900 px-1 py-0.5 rounded text-cyan-400 font-mono">your_gemini_api_key</code> with your actual key. This command creates a <code className="bg-slate-900 px-1 py-0.5 rounded text-cyan-400 font-mono">.env.local</code> file which is used to securely provide the key to the application.</p>
          <pre className="bg-slate-900 p-3 rounded-lg text-sm text-cyan-300 overflow-x-auto">
            <code>
              echo 'API_KEY="your_gemini_api_key"' &gt; .env.local
            </code>
          </pre>
        </div>

        <div>
          <h4 className="font-bold text-slate-100">Step 2: Install Dependencies</h4>
          <p className="text-sm mb-2">If you haven't already, install the necessary project packages using npm.</p>
           <pre className="bg-slate-900 p-3 rounded-lg text-sm text-cyan-300 overflow-x-auto">
            <code>
              npm install
            </code>
          </pre>
        </div>

        <div>
          <h4 className="font-bold text-slate-100">Step 3: Build the Application</h4>
          <p className="text-sm mb-2">This command compiles the application for production. The build process will embed the key from your <code className="bg-slate-900 px-1 py-0.5 rounded text-cyan-400 font-mono">.env.local</code> file into the final static files.</p>
           <pre className="bg-slate-900 p-3 rounded-lg text-sm text-cyan-300 overflow-x-auto">
            <code>
              npm run build
            </code>
          </pre>
        </div>

         <div>
          <h4 className="font-bold text-slate-100">Step 4: Deploy and Serve</h4>
          <p className="text-sm">After the build is complete, a new folder (usually named <code className="bg-slate-900 px-1 py-0.5 rounded text-cyan-400 font-mono">dist</code> or <code className="bg-slate-900 px-1 py-0.5 rounded text-cyan-400 font-mono">build</code>) will be created. Configure your web server (like Nginx or Apache) on the EC2 instance to serve the static files from this directory.</p>
        </div>
      </div>
       <p className="mt-6 text-xs text-slate-500">
        <span className="font-bold">Security Note:</span> For security, never commit your <code className="bg-slate-900 px-1 py-0.5 rounded text-cyan-400 font-mono">.env.local</code> file or expose your API key in public repositories. Ensure this file is listed in your <code className="bg-slate-900 px-1 py-0.5 rounded text-cyan-400 font-mono">.gitignore</code> file.
      </p>
       <style>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 0.5s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default ApiKeyInstructions;


import { GoogleGenAI, Type } from "@google/genai";
import { EC2InstanceCost } from '../types.ts';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const schema = {
  type: Type.OBJECT,
  properties: {
    instanceType: { type: Type.STRING },
    vcpu: { type: Type.INTEGER },
    memory: { type: Type.NUMBER },
    operatingSystem: { type: Type.STRING },
    ebsVolumeType: { type: Type.STRING },
    ebsVolumeSizeGB: { type: Type.INTEGER },
    numberOfInstances: { type: Type.INTEGER },
    instanceCostUSD: { type: Type.NUMBER },
    osCostUSD: { type: Type.NUMBER },
    ebsCostUSD: { type: Type.NUMBER },
    totalMonthlyCostUSD: { type: Type.NUMBER },
  },
  required: [
    "instanceType",
    "vcpu",
    "memory",
    "operatingSystem",
    "ebsVolumeType",
    "ebsVolumeSizeGB",
    "numberOfInstances",
    "instanceCostUSD",
    "osCostUSD",
    "ebsCostUSD",
    "totalMonthlyCostUSD",
  ],
};

export async function fetchEC2Cost(
    instanceType: string,
    os: string,
    ebsVolumeType: string,
    ebsVolumeSizeGB: number,
    numberOfInstances: number
): Promise<EC2InstanceCost> {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY is not configured in the environment.");
  }

  try {
    const prompt = `Provide the estimated monthly on-demand cost breakdown for ${numberOfInstances} AWS EC2 instance(s) of type '${instanceType}' running '${os}' with a ${ebsVolumeSizeGB}GB '${ebsVolumeType}' EBS volume each in the 'us-east-1' region. Provide the total cost for the instances, the total OS cost (if applicable, otherwise 0), the total EBS volume cost, and the grand total monthly cost in US dollars. Also provide the instance's vCPU count and memory in GiB, and the number of instances.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
      },
    });

    const jsonText = response.text.trim();
    if (!jsonText) {
        throw new Error("The AI returned an empty response. Please try again.");
    }
    
    const parsedData = JSON.parse(jsonText) as EC2InstanceCost;
    
    // Basic validation
    if (typeof parsedData.instanceType !== 'string' || typeof parsedData.totalMonthlyCostUSD !== 'number') {
        throw new Error("Received malformed data from the AI.");
    }
    
    return parsedData;
  } catch (error) {
    console.error("Error fetching EC2 cost from Gemini API:", error);
    if (error instanceof Error && error.message.includes('JSON')) {
        throw new Error("Failed to parse the AI's response. The data format might be incorrect.");
    }
    throw new Error("Could not fetch the cost estimate. The AI service may be temporarily unavailable.");
  }
}